// var jQueryScript = document.createElement('script');  
// jQueryScript.setAttribute('src',"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js");
// document.head.appendChild(jQueryScript);

var scrollPercent= null, timeDifference=null, timeSpent = false, landedTime = new Date(), currentRecord=null;
var htmlElement = document.documentElement, 
    bodyElement = document.body,
    scrollTop = 'scrollTop',
    scrollHeight = 'scrollHeight';
var pageTitle=document.querySelector(".page-title").textContent;
// var post_data = {"cl_timeSpent": -1," cl_scrollPercentage": -1,"pl_timeSpent": -1,"pl_scrollPercentage":-1,"hl_timeSpent":-1,"hl_scrollPercentage":-1,"el_timeSpent":-1,"el_scrollPercentage":-1}
var loc_timeSpent=-1, loc_scrollPercentage=-1, al_scrollPercentage=-1, al_timeSpent=-1, hl_timeSpent=-1,hl_scrollPercentage=-1, el_scrollPercentage=-1, el_timeSpent=-1, pl_timeSpent=-1, pl_scrollPercentage = -1;
var counter = 0;
document.getElementById("welcome-text").innerHTML="Welcome " + localStorage.getItem("customer_id")+"!"

window.setTimeout(function(){
    // timeSpent=true; 
    scrollPercent = Math.round((htmlElement[scrollTop]||bodyElement[scrollTop]) / ((htmlElement[scrollHeight]||bodyElement[scrollHeight]) - htmlElement.clientHeight) * 100);
    timeDifference = Math.round((new Date().getTime()-landedTime.getTime())/1000);
    if(pageTitle=="Car Loan"){
        al_scrollPercentage = scrollPercent
        al_timeSpent = timeDifference
    }
    else if(pageTitle=="Home Loan"){
        hl_scrollPercentage = scrollPercent
        hl_timeSpent = timeDifference
    }
    else if(pageTitle=="Personal Loan"){
        pl_scrollPercentage = scrollPercent
        pl_timeSpent = timeDifference
    }
    else if(pageTitle=="Educational Loan"){
        el_scrollPercentage = scrollPercent
        el_timeSpent = timeDifference
    }
    else if(pageTitle=="Borrow Credit Card"){
        loc_scrollPercentage = scrollPercent
        loc_timeSpent = timeDifference
    }

    var currentRecord = {
            customer_id:localStorage.getItem("customer_id"),
            userdata: {"cl_timeSpent": cl_timeSpent," cl_scrollPercentage": cl_scrollPercentage,"pl_timeSpent": pl_timeSpent,"pl_scrollPercentage":pl_scrollPercentage,"hl_timeSpent":hl_timeSpent,"hl_scrollPercentage":hl_scrollPercentage,"el_timeSpent":el_timeSpent,"el_scrollPercentage":el_scrollPercentage}
    };
    console.log("record", currentRecord)
    $.ajax
    ({
        url:"https://lst2qcya53.execute-api.ap-south-1.amazonaws.com/persona/",
        type: 'POST',
        headers: { 
            'Accept': 'application/json',
            'Content-Type': 'application/json' 
        },
        data: JSON.stringify(currentRecord),
        dataType: 'json',
        success: function(data){
            console.log(data);
        },
        error: function() {
            console.log("failed");
        }
    });
}, 10000);

document.addEventListener("scroll", function(event){
    scrollPercent = Math.round((htmlElement[scrollTop]||bodyElement[scrollTop]) / ((htmlElement[scrollHeight]||bodyElement[scrollHeight]) - htmlElement.clientHeight) * 100);
    console.log(scrollPercent)
    if(scrollPercent >= 50 && counter == 0){
        counter += 1;
        timeDifference = Math.round((new Date().getTime()-landedTime.getTime())/1000);
        if(pageTitle=="Car Loan"){
            cl_scrollPercentage = scrollPercent
            cl_timeSpent = timeDifference
        }
        else if(pageTitle=="Home Loan"){
            hl_scrollPercentage = scrollPercent
            hl_timeSpent = timeDifference
        }
        else if(pageTitle=="Personal Loan"){
            pl_scrollPercentage = scrollPercent
            pl_timeSpent = timeDifference
        }
        else if(pageTitle=="Educational Loan"){
            el_scrollPercentage = scrollPercent
            el_timeSpent = timeDifference
        }
        currentRecord = {
                customer_id:localStorage.getItem("customer_id"),
                userdata: {"cl_timeSpent": cl_timeSpent," cl_scrollPercentage": cl_scrollPercentage,"pl_timeSpent": pl_timeSpent,"pl_scrollPercentage":pl_scrollPercentage,"hl_timeSpent":hl_timeSpent,"hl_scrollPercentage":hl_scrollPercentage,"el_timeSpent":el_timeSpent,"el_scrollPercentage":el_scrollPercentage}
        };
        $.ajax
        ({
            url:"https://lst2qcya53.execute-api.ap-south-1.amazonaws.com/persona/",
            type: 'POST',
            headers: { 
                'Accept': 'application/json',
                'Content-Type': 'application/json' 
            },
            data: JSON.stringify(currentRecord),
            dataType: 'json',
            success: function(data){
                console.log("success",data);
                // count += count;
            },
            error: function() {
                console.log("failed");
            }
        });  
        console.log("record",currentRecord)
    }  
});


