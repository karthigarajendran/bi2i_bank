from flask import Flask, render_template
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/homeloan')
def hloan():
    return render_template('home-loan.html')

@app.route('/personalloan')
def ploan():
    return render_template('personal-loan.html')

@app.route('/creditcard')
def ccard():
    return render_template('credit-card-listing.html')

@app.route('/carloan')
def carloan():
    return render_template('car-loan.html')

@app.route('/educationloan')
def educationloan():
    return render_template('education-loan.html')

@app.route('/blog')
def blog():
    return render_template('blog-listing.html')

@app.route('/readblog')
def readblog():
    return render_template('blog-single.html')

@app.route('/compareloan')
def compareloan():
    return render_template('compare-loan.html')

@app.route('/loaneligibility')
def loaneligibility():
    return render_template('loan-eligibility.html')

@app.route('/loancalculator')
def loancalculator():
    return render_template('loan-calculator.html')

@app.route('/aboutus')
def aboutus():
    return render_template('about.html')

@app.route('/contactus')
def contactus():
    return render_template('contact-us.html')

@app.route('/team')
def team():
    return render_template('team.html')


if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True, port=8001)
